package com.lar.pruebaservicioeterno;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import androidx.annotation.Nullable;

import java.util.Calendar;

import static com.lar.pruebaservicioeterno.App.CHANNEL_MAIN_service;

public class ServicioEterno extends IntentService {
    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */

    private PowerManager.WakeLock wakeLock;
    public ServicioEterno() {
        super("ServicioEterno");
        setIntentRedelivery(true);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        ///
        for (int i =0; i<100000;i++){
            SystemClock.sleep(5000);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"pruebaservicioeterno:Wakelock");
        wakeLock.acquire();

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.O)
        {

            Notification notification = new Notification.Builder(this,CHANNEL_MAIN_service)

                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setVisibility(Notification.VISIBILITY_SECRET)
                    .setContentTitle("Click para ocultar esta notificación")
                    .setContentIntent(notificationIntent(this))
                    .build();
            startForeground(1, notification);
        }
            newAlarm(4,2);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        wakeLock.release();
    }

    private PendingIntent notificationIntent(Context context){
        Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName())
                .putExtra(Settings.EXTRA_CHANNEL_ID, CHANNEL_MAIN_service)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(context,0,i,0);

        return pendingIntent;
    }

    private void newAlarm(int hour,int num){
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());

        c.set(Calendar.HOUR_OF_DAY,hour);
        c.set(Calendar.MINUTE,15);

        startAlarm(c,num);
    }

    private void startAlarm(Calendar c,int alarmNum){
        AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(getApplicationContext(), AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),alarmNum,intent,0);

        //alarmManager.setExact(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pendingIntent);
        alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_FIFTEEN_MINUTES,pendingIntent);
    }
}
