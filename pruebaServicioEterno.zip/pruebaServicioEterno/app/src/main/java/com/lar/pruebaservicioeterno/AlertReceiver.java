package com.lar.pruebaservicioeterno;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import static com.lar.pruebaservicioeterno.App.CHANNEL_DIARY;

public class AlertReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

            NotificationCompat.Builder notification = new NotificationCompat.Builder(context.getApplicationContext(), CHANNEL_DIARY)
                    .setContentTitle("¿Cómo te sientes hoy?")
                    .setSmallIcon(R.mipmap.ic_launcher);

            notificationManager.notify(2, notification.build());
        }
    }
}
